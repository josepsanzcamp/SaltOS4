INSERT INTO app_leads_status (id, active, name, description) VALUES
(1, 1, 'New', 'Lead just created'),
(2, 1, 'Contacted', 'Initial contact made'),
(3, 1, 'Qualified', 'Qualified lead'),
(4, 1, 'Proposal Sent', 'Proposal has been delivered'),
(5, 1, 'Negotiation', 'Under negotiation'),
(6, 1, 'Won', 'Deal closed successfully'),
(7, 1, 'Lost', 'Lead lost'),
(8, 1, 'Archived', 'No longer active'),
(9, 1, 'Recycled', 'Revived from previous loss'),
(10, 1, 'Unreachable', 'Could not be contacted')
;
