INSERT INTO app_company (
    id, active, name, code, address, city, province, zip, country,
    phone, email, website, iban, swift,
    fiscal_regime, activity_code, notes
) VALUES
(1, 1, 'SaltOS Solutions SL', 'B12345678', 'Calle Ficticia 123, 3ºA', 'Barcelona', 'Barcelona', '08001', 'Spain', '+34 933 123 456', 'info@saltos.org', 'https://www.saltos.org', 'ES76 1234 5678 9101 2345 6789', 'BESMESMMXXX', 'RE - Régimen General', '8299', 'Entidad acogida al régimen general del IVA');
