INSERT INTO app_types (id, active, name, description) VALUES
(1, 1, 'Type 1', 'Descripción en Español'),
(2, 1, 'Type 2', 'Description in English'),
(3, 1, 'Тип 3', 'Описание на русском'),
(4, 1, '类型 4', '中文描述'),
(5, 1, 'タイプ 5', '日本語の説明'),
(6, 1, '유형 6', '한국어 설명'),
(7, 1, 'Tipo 7', 'Descrizione in Italiano'),
(8, 1, 'Type 8', 'Beschreibung auf Deutsch'),
(9, 1, 'Type 9', 'La description en Français'),
(10, 1, 'Tipo 10', 'Descrição em Português');
