INSERT INTO app_types (id, active, name, description) VALUES
(1, 1, 'Type 1', 'Descripción en Español'), -- Español
(2, 1, 'Type 2', 'Description in English'), -- Inglés
(3, 1, 'Тип 3', 'Описание на русском'), -- Ruso
(4, 1, '类型 4', '中文描述'), -- Chino
(5, 1, 'タイプ 5', '日本語の説明'), -- Japonés
(6, 1, '유형 6', '한국어 설명'), -- Coreano
(7, 1, 'Tipo 7', 'Descrizione in Italiano'), -- Italiano
(8, 1, 'Type 8', 'Beschreibung auf Deutsch'), -- Alemán
(9, 1, 'Type 9', 'La description en Français'), -- Francés
(10, 1, 'Tipo 10', 'Descrição em Português'), -- Portugués
(11, 1, 'Typ 11', 'Beskrivning på Svenska'), -- Sueco
(12, 1, 'Τύπος 12', 'Περιγραφή στα Ελληνικά'), -- Griego
(13, 1, 'نوع 13', 'الوصف باللغة العربية'), -- Árabe
(14, 1, 'प्रकार 14', 'हिंदी में विवरण'), -- Hindi
(15, 1, 'ประเภท 15', 'คำอธิบายภาษาไทย'), -- Tailandés
(16, 1, 'Tür 16', 'Türkçe açıklama'), -- Turco
(17, 1, 'Tip 17', 'Descriere în Română'), -- Rumano
(18, 1, 'Тип 18', 'Опис на македонски'), -- Macedonio
(19, 1, 'Lloji 19', 'Përshkrimi në Shqip'), -- Albanés
(20, 1, 'Vrsta 20', 'Opis na Hrvatskom'), -- Croata
(21, 1, 'Тип 21', 'Опис на српском'), -- Serbio
(22, 1, 'ชนิด 22', 'รายละเอียดในภาษาไทย'), -- Otro en Tailandés
(23, 1, 'Түрі 23', 'Қазақ тіліндегі сипаттама'), -- Kazajo
(24, 1, 'نوع 24', 'توضيح باللغة الفارسية'), -- Persa (Farsi)
(25, 1, 'שִׁעוּר 25', 'תיאור בעברית'), -- Hebreo
(26, 1, 'Type 26', 'Opis w języku polskim'), -- Polaco
(27, 1, 'Тип 27', 'Опис українською мовою'), -- Ucraniano
(28, 1, 'Typ 28', 'Popis v češtině'), -- Checo
(29, 1, 'Type 29', 'Leírás magyar nyelven'), -- Húngaro
(30, 1, 'Vrsta 30', 'Opis na Slovenskem jeziku'), -- Esloveno
(31, 1, 'ชนิด 31', 'คำอธิบายเพิ่มเติมในภาษาไทย'), -- Otro en Tailandés
(32, 1, 'Típus 32', 'Leírás magyar nyelven'), -- Húngaro (duplicado para variedad)
(33, 1, 'نوع 33', 'الوصف باللغة الكردية'), -- Kurdo
(34, 1, 'Typ 34', 'Opis w języku słowackim'), -- Eslovaco
(35, 1, 'Typ 35', 'Beskrivelse på Dansk'), -- Danés
(36, 1, 'Tip 36', 'Descriere în limba moldovenească'), -- Moldavo
(37, 1, 'Tür 37', 'Açıklama Özbek Türkçesi'), -- Uzbeko
(38, 1, 'Тип 38', 'Опис на беларускім'), -- Bielorruso
(39, 1, 'Tip 39', 'Opis na Bosanskom jeziku'), -- Bosnio
(40, 1, 'Typ 40', 'Lýsing á íslensku'), -- Islandés
(41, 1, 'Τύπος 41', 'Περιγραφή στα Κυπριακά Ελληνικά'), -- Griego chipriota
(42, 1, 'Type 42', 'Apraksts latviešu valodā'), -- Letón
(43, 1, 'Type 43', 'Aprašymas lietuvių kalba'), -- Lituano
(44, 1, 'Type 44', 'Kirjeldus eesti keeles'), -- Estonio
(45, 1, 'Tip 45', 'Opis na Malteż'), -- Maltés
(46, 1, 'Тип 46', 'Опис на киргизском языке'), -- Kirguís
(47, 1, 'Тур 47', 'Татарча тасвирлама'), -- Tártaro
(48, 1, 'टाइप 48', 'नेपालीमा विवरण'), -- Nepalí
(49, 1, 'မော်တော် 49', 'မြန်မာဘာသာဖြင့် ဖော်ပြချက်'), -- Birmano
(50, 1, 'ประเภท 50', 'คำอธิบายเพิ่มเติมภาษาเวียดนาม'); -- Vietnamita

