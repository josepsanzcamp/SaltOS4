INSERT INTO app_payment_methods (id, name, description, active, `default`) VALUES
(1, 'Cash', 'Payment made in physical currency.', 1, 0),
(2, 'Credit Card', 'Payment made using a credit card.', 1, 0),
(3, 'Debit Card', 'Payment made using a debit card linked to a bank account.', 1, 0),
(4, 'Bank Transfer', 'Payment made via wire transfer or electronic banking.', 1, 1),
(5, 'PayPal', 'Payment made using a PayPal account.', 1, 0),
(6, 'Cheque', 'Payment made using a paper cheque.', 1, 0),
(7, 'Mobile Payment', 'Payment made using a mobile wallet or app.', 1, 0),
(8, 'Cryptocurrency', 'Payment made using Bitcoin or other cryptocurrencies.', 1, 0),
(9, 'Direct Debit', 'Payment directly withdrawn from a bank account.', 1, 0),
(10, 'Prepaid', 'Payment made using prepaid balance or voucher.', 1, 0),
(11, 'Gift Card', 'Payment using a store-issued gift card.', 1, 0),
(12, 'Other', 'Other form of payment not listed above.', 1, 0);
