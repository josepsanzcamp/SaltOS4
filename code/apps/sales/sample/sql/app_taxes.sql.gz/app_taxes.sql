INSERT INTO `app_taxes` (`id`, `name`, `description`, `value`, `active`, `default`) VALUES
(1, 'VAT 21%', 'Standard VAT rate of 21%', 21.0, 1, 1),
(2, 'VAT 10%', 'Reduced VAT rate of 10%', 10.0, 1, 0),
(3, 'VAT 4%', 'Super-reduced VAT rate of 4%', 4.0, 1, 0),
(4, 'Exempt / Not subject', 'Operations exempt or not subject to VAT', 0.0, 1, 0);
