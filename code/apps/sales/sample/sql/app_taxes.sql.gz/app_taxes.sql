INSERT INTO `app_taxes` (`id`, `type`, `name`, `description`, `value`, `active`, `default`) VALUES
(1, 0, 'IVA 21%', 'Standard VAT rate of 21%', 21.0, 1, 1),
(2, 0, 'IVA 10%', 'Reduced VAT rate of 10%', 10.0, 1, 0),
(3, 0, 'IVA 4%', 'Super-reduced VAT rate of 4%', 4.0, 1, 0),
(4, 0, 'Exempt / Not subject', 'Operations exempt or not subject to VAT', 0.0, 1, 0),
(5, 1, 'IRPF 15%', 'Standard income tax withholding of 15%', 15.0, 1, 0),
(6, 1, 'IRPF 7%', 'Reduced income tax withholding of 7%', 7.0, 1, 0);
