INSERT INTO `app_taxes` (`id`, `name`, `value`, `active`, `default`) VALUES
(1, 'IVA 21%', 21.0, 1, 1),
(2, 'IVA 10%', 10.0, 1, 0),
(3, 'IVA 4%', 4.0, 1, 0),
(4, 'Exento / No sujeto', 0.0, 1, 0);