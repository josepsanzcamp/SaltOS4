INSERT INTO app_invoices_status (id, active, name, description) VALUES
(1, 1, 'Draft', 'Invoice not finalized'),
(2, 1, 'Issued', 'Invoice has been issued'),
(3, 1, 'Partially Paid', 'Invoice partially paid'),
(4, 1, 'Paid', 'Invoice fully paid'),
(5, 1, 'Overdue', 'Payment is overdue'),
(6, 1, 'Cancelled', 'Invoice was cancelled'),
(7, 1, 'Disputed', 'Client raised an issue'),
(8, 1, 'Refunded', 'Invoice was refunded'),
(9, 1, 'Archived', 'Archived for historical reference'),
(10, 1, 'Closed', 'Invoice closed with no further action')
;
