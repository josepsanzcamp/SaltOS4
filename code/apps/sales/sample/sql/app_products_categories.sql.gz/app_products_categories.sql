INSERT INTO app_products_categories (id, active, name, description) VALUES
(1, 1, 'Hardware', 'Physical devices and equipment'),
(2, 1, 'Software', 'Applications and systems'),
(3, 1, 'Services', 'Technical or support services'),
(4, 1, 'Licenses', 'Software or intellectual property licenses'),
(5, 1, 'Training', 'Courses and educational content'),
(6, 1, 'Maintenance', 'Post-sale repair or update services'),
(7, 1, 'Cloud', 'Hosted online services'),
(8, 1, 'Accessories', 'Complementary items'),
(9, 1, 'Consumables', 'Items that are used and replaced'),
(10, 1, 'Other', 'Unclassified category')
;
